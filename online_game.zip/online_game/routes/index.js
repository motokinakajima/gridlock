const express = require('express');
const router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
    let data = {
        isPost:false,
        usrName:'',
        roomID:''
    };
    res.render('index',data);
});
router.post('/',function(req,res,next){
    let data = {
        isPost:true,
        usrName:req.body.playerName,
        roomID:req.body.roomID
    };
    console.log(req.body);
    console.log(data);
    console.log(req.body.roomID);
    console.log(req.body.playerName);
    res.render('index',data);
    console.log('send-data');
});
module.exports = router;
